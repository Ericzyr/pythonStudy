#!/bin/bash
pause(){
 read -n 1 -p"$*" INP
}

for line in `cat caselist2.0_CN.txt`
   do
      echo $line
		testCase=`echo $line| awk -F "," '{print $1}'`
		case_name=`echo $line|awk -F# '{print $2}'|awk -F "," '{print $1}'`
    #  echo $testCase
     
# echo $case_name
		#case avgs
		case_avg=`echo $line|awk -F "," '{for(i=2;i<=NF;i++)a=a " -e " $i;print a}'|tr ":" " "`
		echo $case_avg
		#current_case_folder=${case_name}_`date '+%Y%m%d_%H%M%S'`		
		#mkdir -p $result_folder/'LOOP'$i/$current_case_folder
		#echo "INSTRUMENTATION_STATUS: class=$line" > $current_case_log
		#adb -s ${IPADDRESS} shell busybox pkill uiautomator
		#reconnect 5
	
	done
pause 'press any key to continue'
read choise
echo $choise

read -p "提示一个输入" aa
echo $aa
echo "结果文件"
read resultfolder
echo $resultfolder

IP=""
if [ $# -eq 4 ]; then
echo "1234"
   # echo $1
   #aa= `echo $1|awk -F. '{print NF}' `
   #echo "$aa"
    case `echo $1|awk -F. '{print NF}'` in
    4)
     IP=$1
     #echo "$IP"
    ;;
    5)
     IP=$1":5555"
    ;;
    esac
fi
echo $IP

local a=0
while true do
    
    case `adb shell 192.168.1.112 ls|grep -c -w data` in
    0)
      adb connect 192.168.1.112
    ;;
    1)
     echo "lianshangle"
    ;;
    esac
  a = $((a+1))

done

read Type
if [ $Type == "1"]; then
  caselist="1.txt"
  ttye="ATV"
elif [ $Type == "2"]; then
caselist="2.txt"
  ttye="CIBN"
fi

#adb -s ${IPADDRESS} shell pm uninstall com.android.testing.dummyime 
#python parse.py ${IPADDRESS} $ci $result_folder
#mkdir $result_folder/Pss_Cpu
#adb -s ${IPADDRESS} pull /sdcard/Pss_Cpu $result_folder/Pss_Cpu
#pid=` awk -F "," '{print $1}' $result_folder/Pss_Cpu/State.txt`
#print $pid
#adb -s ${IPADDRESS} shell kill -9 $pid
#python formatter.py $result_folder/Pss_Cpu/procrank.csv out.csv $result_folder
#python cpuformatter.py $result_folder/Pss_Cpu/top.csv topout.csv $result_folder
#cp htmlTemplate/cpuPic.htm ${BUILD_ID}
#cp $result_folder/Pss_Cpu/cpu.csv ${BUILD_ID}
